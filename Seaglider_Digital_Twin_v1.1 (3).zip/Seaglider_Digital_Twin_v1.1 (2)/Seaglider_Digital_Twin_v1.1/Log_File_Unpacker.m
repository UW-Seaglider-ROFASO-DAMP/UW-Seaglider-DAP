function MissionMatrix = Log_File_Unpacker(filename)
% LOG_FILE_UNPACKER
%
% Reads an AUV mission log file and converts ALL parameter/value pairs
% into a MATLAB cell matrix.
%
% The first row contains parameter names.
% The second row contains associated values.
%
% Supports:
%   parameter:value
%   parameter,value
%
% Example:
%
%   MissionMatrix = Log_File_Unpacker('p1950004.log');
%
% Access examples:
%
%   % Get parameter names
%   names = MissionMatrix(1,:);
%
%   % Get parameter values
%   values = MissionMatrix(2,:);
%
%   % Find a specific parameter
%   idx = strcmp(MissionMatrix(1,:), '$D_TGT');
%   targetDepth = MissionMatrix{2,idx};

%% Open file
fid = fopen(filename,'r');

if fid == -1
    error('Could not open file.');
end

%% Initialize storage
names  = {};
values = {};

%% Read file line-by-line
while ~feof(fid)

    line = strtrim(fgetl(fid));

    % Skip empty lines
    if isempty(line)
        continue;
    end

    %% CASE 1: Colon-separated
    % Example:
    % version: 66.14

    if contains(line, ':')

        splitLine = strsplit(line, ':');

        if length(splitLine) >= 2

            paramName = strtrim(splitLine{1});

            % Join remaining pieces in case multiple colons exist
            paramValue = strtrim(strjoin(splitLine(2:end), ':'));

            names{end+1}  = paramName;
            values{end+1} = paramValue;

        end

    %% CASE 2: Comma-separated
    % Example:
    % $ID,195

    elseif contains(line, ',')

        splitLine = strsplit(line, ',');

        paramName = strtrim(splitLine{1});

        % Everything after first comma becomes value string
        paramValue = strjoin(splitLine(2:end), ',');

        names{end+1}  = paramName;
        values{end+1} = paramValue;

    end

end

%% Close file
fclose(fid);

%% Build output matrix
MissionMatrix = [names; values]';

%% Display summary
fprintf('\n====================================\n');
fprintf('Log File Successfully Parsed\n');
fprintf('====================================\n');

fprintf('Total Parameters Loaded: %d\n', length(names));

fprintf('====================================\n');

end