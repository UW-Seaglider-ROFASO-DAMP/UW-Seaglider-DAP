%% SEAGLIDER D.A.P. system 

% The goal of this code is to diagnose and isolate a fault on a seaglider

%% Inputs
% Log and Eng files from desired mission

%% Outputs
% fault diagnose of wing or rudder and percentage loss

%% Authors
% Jordan Cummings, Henry Hong, Holland Kanter, Letizia Laura, Edward Park, 
% Oleksiy Polyakov, Geenadie Rathnayake, Joshua Rolfe, Mak Sukimoto, 
% Dante Weerasooriya, Kyle Wittcoff

%% Updated on
% 05/03/2026

%% Files required
% log_files, eng_files, DAP_Main.m, dynamicsV3.m, FaultIsolator.m,
% missioncompare.m, nc_file_reader_function.m, nc_file_reader_script.m,
% parameters.m


clear
clc

%% Log file unpacking
% This section unpacks the log file into a matrix

Log_Matrix = Log_File_Unpacker('p1750005.log'); % USER INPUT - insert name of log file into the ('');   Example - ('p1950001.log') 


%% NC file unpacking
% This section unpacks the eng file into a matrix

NC_Matrix = NC_File_Unpacker('p1750005.nc'); % USER INPUT - insert name of eng file into the ('');   Example - ('p1950001.eng') 


%% Mission Data Matrix

Mission_Data_Matrix = Create_Mission_Data_Matrix(Log_Matrix, NC_Matrix);

%% Parameters
% Input variables for pressure, temperature
%% Dynamics


Nom_Sim_Matrix = Create_Dynamics_Matrix(Mission_Data_Matrix, coefficientsV3, parametersV3);
% 
% 
% %% Diagnoser
% 
% % Compare simulated nominal mission to actual ENG mission
% Diagnose = missioncompare(Nom_Sim_Matrix, Eng_Matrix);
% 
% % need mission comparator to output totatl error percentange for next stage
% 
% %% Display Diagnose Results
% disp(Diagnose);
% 
% %% If/else statement to determine if the mis-fault comparator will activate
% 
% if total_error >= 40
%     % continue to next iteration of loop, if error bound is => 40%
%     return
% else
%     % stop the loop / exit function, if error bound is < 40%
% end 


%%  Mission Fualt comparator

%% Simulate fault cases
% 75_wing_Sim_Matrix = Create_Dynamics_Matrix(Log_Matrix, NC_Matrix, coefficients_75, parameters_75);
% 
% 50_wing_Sim_Matrix = Create_Dynamics_Matrix(Log_Matrix, NC_Matrix, coefficients_50, parameters_50);
% 
% 25_wing_Sim_Matrix = Create_Dynamics_Matrix(Log_Matrix, NC_Matrix, coefficients_50, parameters_50);
% 
% 75_rudder_Sim_Matrix = Create_Dynamics_Matrix(Log_Matrix, NC_Matrix, coefficients_75, parameters_75);
% 
% 50_rudder_Sim_Matrix = Create_Dynamics_Matrix(Log_Matrix, NC_Matrix, coefficients_50, parameters_50);
% 
% 25_rudder_Sim_Matrix = Create_Dynamics_Matrix(Log_Matrix, NC_Matrix, coefficients_50, parameters_50);
% 
% %% Compare fualt case matricies to mission data
% 
% Isolate_75_wing = missioncompare(75_Sim_Matrix, Eng_Matrix);
% 
% Isolate_50_wing = missioncompare(50_Sim_Matrix, Eng_Matrix);
% 
% Isolate_25_wing = missioncompare(50_Sim_Matrix, Eng_Matrix);
% 
% Isolate_75_rudder = missioncompare(75_Sim_Matrix, Eng_Matrix);
% 
% Isolate_50_rudder = missioncompare(50_Sim_Matrix, Eng_Matrix);
% 
% Isolate_25_rudder = missioncompare(50_Sim_Matrix, Eng_Matrix);
% 
% %% graph and display results
% 
% % graph each error % from simulatated case
% % display lowest total error
% % say 'The most likely fault is xx% wing/rudder brakage based on data'
% 
% 
% 
% 













