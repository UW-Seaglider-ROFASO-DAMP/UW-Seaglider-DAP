function Sim_Matrix = Create_Dynamics_Matrix(Log_Matrix, Eng_Matrix, coefs, params)

    % Output has same size/format as Eng_Matrix
    Sim_Matrix = Eng_Matrix;

    % Clean Eng headers
    engHeaders = strtrim(string(Eng_Matrix(1,:)));

    % Convert Eng numeric data
    engData = cell2mat(Eng_Matrix(2:end,:));

    % Number of rows to simulate
    numRows = size(engData,1);

    % Find Eng columns
    engTimeIdx  = findColumn(engHeaders, ["elaps_t", "time", "secs", "st_secs"]);
    engDepthIdx = findColumn(engHeaders, ["depth"]);
    engHeadIdx  = findColumn(engHeaders, ["head", "heading"]);
    engPitchIdx = findColumn(engHeaders, ["pitchANG", "pitchAng", "pitch_ang", "pitch"]);
    engRollIdx  = findColumn(engHeaders, ["rollANG", "rollAng", "roll_ang", "roll"]);

    engPitchCtlIdx = findColumn(engHeaders, ["pitchCtl", "pitch_ctl", "pitch_control"]);
    engRollCtlIdx  = findColumn(engHeaders, ["rollCtl", "roll_ctl", "roll_control"]);

    % Your Eng file uses vbdCC
    engVBDIdx = findColumn(engHeaders, ["vbdCC", "vbdCtl", "vbd_ctl", "vbd", "vbd_ad", "vbd_ctlAD"]);

    % Error checks
    if isempty(engTimeIdx),     error("Missing Eng time column."); end
    if isempty(engDepthIdx),    error("Missing Eng depth column."); end
    if isempty(engHeadIdx),     error("Missing Eng heading column."); end
    if isempty(engPitchIdx),    error("Missing Eng pitch angle column."); end
    if isempty(engRollIdx),     error("Missing Eng roll angle column."); end
    if isempty(engPitchCtlIdx), error("Missing Eng pitch control column."); end
    if isempty(engRollCtlIdx),  error("Missing Eng roll control column."); end

    if isempty(engVBDIdx)
        disp("Available Eng headers:");
        disp(engHeaders');
        error("Missing Eng VBD column.");
    end

    % Initial state vector:
    % X = [phidot; thetadot; headingdot; phi; theta; heading; u; v; w; x; y; z]
    X = zeros(12,1);

    X(4)  = engData(1, engRollIdx);      % roll angle
    X(5)  = engData(1, engPitchIdx);     % pitch angle
    X(6)  = engData(1, engHeadIdx);      % heading
    X(12) = engData(1, engDepthIdx);     % depth

    % Iterate through Eng rows
    for k = 1:numRows

        % Time step
        if k > 1
            dt = engData(k, engTimeIdx) - engData(k-1, engTimeIdx);
        else
            dt = 1;
        end

        if dt <= 0
            dt = 1;
        end

        % Control input for dynamicsV3:
        % U = [x_bat; phi_bat; VBD_ctlAD]
        U = zeros(3,1);
        U(1) = engData(k, engPitchCtlIdx);
        U(2) = engData(k, engRollCtlIdx);
        U(3) = engData(k, engVBDIdx);

        % Update changing parameters
        params.heading_desired = engData(k, engHeadIdx);
        params.pressure = engData(k, engDepthIdx);

        % Run dynamicsV3
        Xdot = dynamicsV3(X, U, coefs, params);

        % Euler integration
        X = X + Xdot * dt;

        % Replace pitchAng and rollAng in output matrix
        Sim_Matrix{k+1, engPitchIdx} = X(5);
        Sim_Matrix{k+1, engRollIdx}  = X(4);

    end

end


function idx = findColumn(headers, possibleNames)

    idx = [];

    for i = 1:length(possibleNames)
        idx = find(strcmpi(headers, possibleNames(i)), 1);

        if ~isempty(idx)
            return;
        end
    end

end