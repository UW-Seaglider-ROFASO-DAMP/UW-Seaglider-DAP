function Mission_Data_Matrix = Create_Mission_Data_Matrix(Log_Matrix, NC_Matrix)
% CREATE_MISSION_DATA_MATRIX
%
% Combines important Log file parameters and NC file data into one matrix.
%
% INPUTS:
%   Log_Matrix - output from Log_File_Unpacker
%                Column 1 = names
%                Column 2 = values
%
%   NC_Matrix  - output from NC_File_Unpacker
%                Row 1 = variable names
%                Rows 2:end = data
%
% OUTPUT:
%   Mission_Data_Matrix
%       Row 1 = variable names
%       Rows 2:end = numeric mission data

%% =========================================================
% SELECT IMPORTANT LOG PARAMETERS HERE
% ==========================================================

logNames = { ...
    '$RHO', ...
    '$C_PITCH', ...
    '$C_ROLL_DIVE', ...
    '$C_ROLL_CLIMB', ...
    '$MHEAD_RNG_PITCHd_Wd', ...
    '$C_VBD', ...
    };

%% =========================================================
% SELECT IMPORTANT NC VARIABLES HERE
% ==========================================================

ncNames = { ...
    'eng_elaps_t_0000', ...
    'eng_elaps_t', ...
    'eng_depth', ...
    'eng_head', ...
    'eng_pitchAng', ...
    'eng_rollAng', ...
    'eng_pitchCtl', ...
    'eng_rollCtl', ...
    'eng_vbdCC', ...
    'temperature', ...
    'log_RHO', ...
    'pressure', ...
    'horz_speed_gsm', ...
    'vert_speed_gsm' ...
    };

%% =========================================================
% EXTRACT NC DATA
% ==========================================================

NC_headers = NC_Matrix(1,:);
NC_data = cell2mat(NC_Matrix(2:end,:));

missionHeaders = {};
missionData = [];

for i = 1:length(ncNames)

    idx = strcmp(NC_headers, ncNames{i});

    if any(idx)

        missionHeaders{end+1} = ncNames{i};
        missionData(:,end+1) = NC_data(:,idx);

    else

        warning('NC variable "%s" not found. Skipping.', ncNames{i});

    end

end

%% =========================================================
% EXTRACT LOG PARAMETERS AND REPEAT DOWN ROWS
% ==========================================================

numRows = size(missionData,1);

for i = 1:length(logNames)

    idx = strcmp(Log_Matrix(:,1), logNames{i});

    if any(idx)

        rowNum = find(idx, 1);

        % Take ONLY the first value after the variable name
        % Column 1 = variable name
        % Column 2 = first value
        value = Log_Matrix{rowNum, 2};

        % Convert only if it is text
        if ischar(value) || isstring(value)
            numericValue = str2double(value);
        else
            numericValue = value;
        end

        if isnan(numericValue)
            warning('Log parameter "%s" is not numeric. Skipping.', logNames{i});
            continue;
        end

        % Repeat log value down to match NC rows
        repeatedColumn = numericValue * ones(numRows,1);

        missionHeaders{end+1} = logNames{i};
        missionData(:,end+1) = repeatedColumn;

    else

        warning('Log parameter "%s" not found. Skipping.', logNames{i});

    end

end

%% =========================================================
% BUILD FINAL MISSION DATA MATRIX
% ==========================================================

Mission_Data_Matrix = [missionHeaders; num2cell(missionData)];

%% =========================================================
% DISPLAY SUMMARY
% ==========================================================

fprintf('\n====================================\n');
fprintf('Mission Data Matrix Created\n');
fprintf('====================================\n');
fprintf('Rows: %d numeric rows + 1 header row\n', numRows);
fprintf('Columns: %d\n', length(missionHeaders));

fprintf('\nMission Data Columns:\n');

for i = 1:length(missionHeaders)
    fprintf('%2d : %s\n', i, missionHeaders{i});
end

fprintf('====================================\n');

end