function Nom_Sim_Matrix = Create_Dynamics_Matrix(Mission_Data_Matrix, coefs, params)
% CREATE_DYNAMICS_MATRIX
%
% Uses Mission_Data_Matrix as the only input.
% Runs dynamicsV3 row-by-row using ode45.
%
% Output:
%   Nom_Sim_Matrix = Mission_Data_Matrix with simulated values replacing:
%       eng_pitchAng
%       eng_rollAng
%       vert_speed_gsm
%       horz_speed_gsm


%% Separate headers and numeric data
headers = strtrim(string(Mission_Data_Matrix(1,:)));
data = cell2mat(Mission_Data_Matrix(2:end,:));

numRows = size(data,1);

%% Find required columns
timeIdx  = findColumn(headers, ["eng_elaps_t", "eng_elaps_t_0000"]);
depthIdx = findColumn(headers, ["eng_depth"]);
headIdx  = findColumn(headers, ["eng_head"]);

pitchIdx = findColumn(headers, ["eng_pitchAng", "pitchAng", "pitchANG"]);
rollIdx  = findColumn(headers, ["eng_rollAng", "rollAng", "rollANG"]);

pitchCtlIdx = findColumn(headers, ["eng_pitchCtl", "pitchCtl"]);
rollCtlIdx  = findColumn(headers, ["eng_rollCtl", "rollCtl"]);
vbdIdx      = findColumn(headers, ["eng_vbdCC", "vbdCC"]);

vertSpeedIdx = findColumn(headers, ["vert_speed_gsm", "vertical_speed"]);
horzSpeedIdx = findColumn(headers, ["horz_speed_gsm", "horizontal_speed"]);

cPitchIdx = findColumn(headers, ["$C_PITCH", "C_PITCH"]);
rhoIdx    = findColumn(headers, ["$RHO", "log_RHO"]);

%% Error checks
if isempty(timeIdx), error("Missing time column."); end
if isempty(depthIdx), error("Missing depth column."); end
if isempty(headIdx), error("Missing heading column."); end
if isempty(pitchIdx), error("Missing pitch angle column."); end
if isempty(rollIdx), error("Missing roll angle column."); end
if isempty(pitchCtlIdx), error("Missing pitch control column."); end
if isempty(rollCtlIdx), error("Missing roll control column."); end
if isempty(vbdIdx), error("Missing VBD control column."); end
if isempty(vertSpeedIdx), error("Missing vertical speed column."); end
if isempty(horzSpeedIdx), error("Missing horizontal speed column."); end

%% Create output matrix
Nom_Sim_Matrix = Mission_Data_Matrix;

%% Initial state vector
% X = [phidot; thetadot; headingdot; phi; theta; heading; u; v; w; x; y; z]

X0 = zeros(12,1);

X0(4)  = data(1, rollIdx);       % roll angle, deg
X0(5)  = data(1, pitchIdx);      % pitch angle, deg
X0(6)  = data(1, headIdx);       % heading, deg
X0(7)  = data(1, horzSpeedIdx);  % horizontal speed
X0(8)  = 0;                      % lateral speed
X0(9)  = data(1, vertSpeedIdx);  % vertical speed
X0(12) = data(1, depthIdx);      % depth

X = X0;

%% Loop through mission rows
for k = 1:numRows

    %% Time step
    if k < numRows
        dt = data(k+1,timeIdx) - data(k,timeIdx);
    else
        dt = 1;
    end

    if dt <= 0 || isnan(dt) || isinf(dt)
        dt = 1;
    end

    %% Update parameters from mission data
    params.heading_desired = data(k, headIdx);
    params.pressure = data(k, depthIdx);

    if ~isempty(rhoIdx)
        params.rho = data(k, rhoIdx);
    end

    if any(headers == "temperature")
        tempIdx = find(headers == "temperature", 1);
        params.temp = data(k, tempIdx);
    end

    %% Build control input vector
    % dynamicsV3 expects:
    % U = [x_bat; phi_bat; VBD_ctlAD]

    pitchCtl = data(k, pitchCtlIdx);
    rollCtl  = data(k, rollCtlIdx);
    vbdCtl   = data(k, vbdIdx);

    % Convert pitch control AD count into battery position
    if ~isempty(cPitchIdx)
        C_pitch = data(k, cPitchIdx);
        pitch_cnv = 0.003125763;
        x_bat = (pitchCtl - C_pitch) * pitch_cnv;
    else
        x_bat = pitchCtl;
    end

    phi_bat = rollCtl;

    U = [x_bat; phi_bat; vbdCtl];

    %% Run ode45
    tspan = [0 dt];

    odeFun = @(t,X) dynamicsV3(X, U, coefs, params);

    [~, Xout] = ode45(odeFun, tspan, X);

    % Final state after time step
    X = Xout(end,:)';

    %% Save simulated outputs
    Nom_Sim_Matrix{k+1, pitchIdx} = X(5);
    Nom_Sim_Matrix{k+1, rollIdx}  = X(4);

    Nom_Sim_Matrix{k+1, horzSpeedIdx} = X(7);
    Nom_Sim_Matrix{k+1, vertSpeedIdx} = X(9);

end

%% Display summary
fprintf('\n====================================\n');
fprintf('Nominal Simulation Matrix Created\n');
fprintf('====================================\n');
fprintf('Rows simulated: %d\n', numRows);
fprintf('Updated columns:\n');
fprintf(' - %s\n', headers(pitchIdx));
fprintf(' - %s\n', headers(rollIdx));
fprintf(' - %s\n', headers(horzSpeedIdx));
fprintf(' - %s\n', headers(vertSpeedIdx));
fprintf('====================================\n');

end

%% Helper function
function idx = findColumn(headers, possibleNames)

idx = [];

for i = 1:length(possibleNames)

    idx = find(strcmpi(headers, possibleNames(i)), 1);

    if ~isempty(idx)
        return;
    end

end

end