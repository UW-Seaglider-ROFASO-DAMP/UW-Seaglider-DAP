function Nom_Sim_Matrix = Digital_Twin(Mission_Data_Matrix, coefs, params)
% DIGITAL_TWIN
%
% Uses Mission_Data_Matrix, coefficients, and parameters.
% Runs dynamicsV3 row-by-row using a fast Euler update.
%
% Output:
%   Nom_Sim_Matrix = Mission_Data_Matrix with simulated values replacing:
%       eng_pitchAng
%       eng_rollAng

%% Separate headers and numeric data
headers = strtrim(string(Mission_Data_Matrix(1,:)));
data = cell2mat(Mission_Data_Matrix(2:end,:));

numRows = size(data,1);

%% Find required columns
timeIdx  = findColumn(headers, ["eng_elaps_t", "eng_elaps_t_0000"]);
depthIdx = findColumn(headers, ["eng_depth"]);
headIdx  = findColumn(headers, ["eng_head"]);

pitchIdx = findColumn(headers, ["eng_pitchAng", "pitchAng", "pitchANG"]);
rollIdx  = findColumn(headers, ["eng_rollAng", "rollAng", "rollANG"]);

pitchCtlIdx = findColumn(headers, ["eng_pitchCtl", "pitchCtl"]);
rollCtlIdx  = findColumn(headers, ["eng_rollCtl", "rollCtl"]);
vbdIdx      = findColumn(headers, ["eng_vbdCC", "vbdCC"]);

cPitchIdx = findColumn(headers, ["$C_PITCH", "C_PITCH"]);
rhoIdx    = findColumn(headers, ["$RHO", "log_RHO"]);
tempIdx   = findColumn(headers, ["temperature", "temp"]);

headingDesiredIdx = findColumn(headers, ...
    ["$MHEAD_RNG_PITCHd_Wd", "MHEAD_RNG_PITCHd_Wd", "log_MHEAD_RNG_PITCHd_Wd"]);

%% Error checks
if isempty(timeIdx), error("Missing time column."); end
if isempty(depthIdx), error("Missing depth column."); end
if isempty(headIdx), error("Missing heading column."); end
if isempty(pitchIdx), error("Missing pitch angle column."); end
if isempty(rollIdx), error("Missing roll angle column."); end
if isempty(pitchCtlIdx), error("Missing pitch control column."); end
if isempty(rollCtlIdx), error("Missing roll control column."); end
if isempty(vbdIdx), error("Missing VBD control column."); end
if isempty(headingDesiredIdx), error("Missing desired heading column."); end

%% Create output matrix
Nom_Sim_Matrix = Mission_Data_Matrix;

%% Initial state vector
% X = [phidot; thetadot; headingdot; phi; theta; heading; u; v; w; x; y; z]
%
% X(1)  = roll rate
% X(2)  = pitch rate
% X(3)  = heading rate
% X(4)  = roll angle
% X(5)  = pitch angle
% X(6)  = heading angle
% X(7)  = horizontal velocity
% X(8)  = lateral velocity
% X(9)  = vertical velocity
% X(10) = x position
% X(11) = y position
% X(12) = depth

X = zeros(12,1);

X(1)  = 0;                    % initial roll rate
X(2)  = 0;                    % initial pitch rate
X(3)  = 0;                    % initial heading rate
X(4)  = data(1, rollIdx);     % roll angle, deg
X(5)  = data(1, pitchIdx);    % pitch angle, deg
X(6)  = data(1, headIdx);     % heading, deg
X(7)  = 0.1;                  % horizontal speed placeholder
X(8)  = 0;                    % lateral speed placeholder
X(9)  = 0.1;                  % vertical speed placeholder
X(10) = 0;
X(11) = 0;
X(12) = data(1, depthIdx);    % depth

%% Loop through mission rows
for k = 1:numRows

    if mod(k,50) == 0
        fprintf('Running Digital Twin row %d of %d\n', k, numRows);
    end

    %% Time step
    if k < numRows
        dt = data(k+1,timeIdx) - data(k,timeIdx);
    else
        dt = 1;
    end

    if dt <= 0 || isnan(dt) || isinf(dt)
        dt = 1;
    end

    % Limit timestep for stability and speed
    dt = min(dt, 1);

    %% Update parameters from Mission_Data_Matrix
    params.heading_desired = data(k, headingDesiredIdx);
    params.pressure = data(k, depthIdx);

    if ~isempty(rhoIdx)
        params.rho = data(k, rhoIdx);
    end

    if ~isempty(tempIdx)
        params.temp = data(k, tempIdx);
    end

    %% Control inputs
    pitchCtl = data(k, pitchCtlIdx);
    rollCtl  = data(k, rollCtlIdx);
    vbdCtl   = data(k, vbdIdx);

    if ~isempty(cPitchIdx)
        C_pitch = data(k, cPitchIdx);
        pitch_cnv = 0.003125763;
        x_bat = (pitchCtl - C_pitch) * pitch_cnv;
    else
        x_bat = pitchCtl;
    end

    phi_bat = rollCtl;

    % dynamicsV3 expects:
    % U = [x_bat; phi_bat; VBD_ctlAD]
    U = [x_bat; phi_bat; vbdCtl];

    %% Protect state before dynamics call

    % Prevent near-zero velocities
    if abs(X(7)) < 1e-3
        X(7) = 1e-3;
    end

    if abs(X(9)) < 1e-3
        X(9) = 1e-3;
    end

    % Keep roll and heading in 0-360 deg range before dynamics
    X(4) = mod(X(4), 360);
    X(6) = mod(X(6), 360);

    % Keep pitch angle realistic
    X(5) = max(min(X(5), 85), -85);

    % Limit roll, pitch, and heading rates
    X(1) = max(min(X(1), 10), -10);
    X(2) = max(min(X(2), 10), -10);
    X(3) = max(min(X(3), 10), -10);

    % Reset bad states
    if any(isnan(X)) || any(isinf(X))
        warning('Bad state detected at row %d. Resetting from mission data.', k);

        X = zeros(12,1);
        X(1)  = 0;
        X(2)  = 0;
        X(3)  = 0;
        X(4)  = mod(data(k, rollIdx), 360);
        X(5)  = max(min(data(k, pitchIdx), 85), -85);
        X(6)  = mod(data(k, headIdx), 360);
        X(7)  = 0.1;
        X(8)  = 0;
        X(9)  = 0.1;
        X(10) = 0;
        X(11) = 0;
        X(12) = data(k, depthIdx);
    end

    %% Fast single-step dynamics update
    try
        Xdot = dynamicsV3(X, U, coefs, params);

        % Protect against NaN or Inf from dynamics
        if any(isnan(Xdot)) || any(isinf(Xdot))
            warning('Bad Xdot at row %d. Holding previous state.', k);
            Xdot = zeros(12,1);
        end

        % Limit extreme angular accelerations
        Xdot(1) = max(min(Xdot(1), 50), -50);   % roll acceleration
        Xdot(2) = max(min(Xdot(2), 50), -50);   % pitch acceleration
        Xdot(3) = max(min(Xdot(3), 50), -50);   % heading acceleration

        % Limit angular rates coming from dynamics output
        Xdot(4) = max(min(Xdot(4), 10), -10);   % roll rate
        Xdot(5) = max(min(Xdot(5), 10), -10);   % pitch rate
        Xdot(6) = max(min(Xdot(6), 10), -10);   % heading rate

        % Limit velocity accelerations
        Xdot(7) = max(min(Xdot(7), 1), -1);
        Xdot(8) = max(min(Xdot(8), 1), -1);
        Xdot(9) = max(min(Xdot(9), 1), -1);

        % Euler integration
        X = X + Xdot * dt;

        % Keep roll angle between 0 and 360 degrees
        X(4) = mod(X(4), 360);

        % Keep heading between 0 and 360 degrees
        X(6) = mod(X(6), 360);

        % Keep pitch angle realistic
        X(5) = max(min(X(5), 85), -85);

        % Limit roll, pitch, and heading rates after integration
        X(1) = max(min(X(1), 10), -10);
        X(2) = max(min(X(2), 10), -10);
        X(3) = max(min(X(3), 10), -10);

    catch ME
        warning('dynamicsV3 failed at mission row %d. Holding previous state. Message: %s', ...
            k, ME.message);
    end

    %% Save simulated pitch and roll only
    Nom_Sim_Matrix{k+1, pitchIdx} = X(5);
    Nom_Sim_Matrix{k+1, rollIdx}  = X(4);

end

%% Display summary
fprintf('\n====================================\n');
fprintf('Nominal Simulation Matrix Created\n');
fprintf('====================================\n');
fprintf('Rows simulated: %d\n', numRows);
fprintf('Updated columns:\n');
fprintf(' - %s\n', headers(pitchIdx));
fprintf(' - %s\n', headers(rollIdx));
fprintf('====================================\n');

end

%% Helper function
function idx = findColumn(headers, possibleNames)

idx = [];

for i = 1:length(possibleNames)

    idx = find(strcmpi(headers, possibleNames(i)), 1);

    if ~isempty(idx)
        return;
    end

end

end