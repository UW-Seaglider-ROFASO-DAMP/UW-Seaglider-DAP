function Eng_Matrix = Eng_File_Unpacker(filename)

    fid = fopen(filename, 'r');
    if fid == -1
        error('Could not open file: %s', filename);
    end

    columnNames = {};
    dataStart = false;
    dataRows = [];

    while ~feof(fid)
        line = strtrim(fgetl(fid));

        % --- Extract column names ---
        if startsWith(line, '%columns:')
            columnText = erase(line, '%columns:');
            columnNames = strtrim(strsplit(columnText, ','));
        end

        % --- Start reading data ---
        if startsWith(line, '%data:')
            dataStart = true;
            continue;
        end

        % --- Read numeric rows ---
        if dataStart && ~isempty(line)
            row = str2num(line); %#ok<ST2NM>

            if ~isempty(row)
                dataRows = [dataRows; row]; %#ok<AGROW>
            end
        end
    end

    fclose(fid);

    % --- Convert numeric matrix to cell ---
    dataCells = num2cell(dataRows);

    % --- Combine headers + data ---
    Eng_Matrix = [columnNames; dataCells];

end