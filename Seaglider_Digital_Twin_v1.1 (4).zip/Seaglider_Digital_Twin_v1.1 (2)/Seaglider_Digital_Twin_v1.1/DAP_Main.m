%% SEAGLIDER D.A.P. system 

% The goal of this code is to diagnose and isolate a fault on a seaglider

%% Inputs
% Log and Eng files from desired mission

%% Outputs
% fault diagnose of wing or rudder and percentage loss

%% Authors
% Jordan Cummings, Henry Hong, Holland Kanter, Letizia Laura, Edward Park, 
% Oleksiy Polyakov, Geenadie Rathnayake, Joshua Rolfe, Mak Sukimoto, 
% Dante Weerasooriya, Kyle Wittcoff

%% Updated on
% 05/08/2026

%% Files required
%% User Inputs
% log_files, eng_files

%% D.A.P. Folder files
% DAP_Main.m, dynamicsV3.m,  FaultIsolator.m, log_file_unpacker.m,
% missioncompare.m, nc_file_reader_function.m, nc_file_reader_script.m,
% parameters.m

clear
clc

%% =========================================================
% SELECT LOG FILE
%% ==========================================================

logMsg = msgbox( ...
    'Please Select Log File', ...
    'Log File Selection', ...
    'modal');

uiwait(logMsg);

[logFile, logPath] = uigetfile( ...
    {'*.log','Log Files (*.log)'}, ...
    'Select Log File');

if isequal(logFile,0)
    error('No Log file selected.');
end

logFullPath = fullfile(logPath, logFile);

%% =========================================================
% SELECT NC FILE
%% ==========================================================

ncMsg = msgbox( ...
    'Please Select NC File', ...
    'NC File Selection', ...
    'modal');

uiwait(ncMsg);

[ncFile, ncPath] = uigetfile( ...
    {'*.nc','NetCDF Files (*.nc)'}, ...
    'Select NC File');

if isequal(ncFile,0)
    error('No NC file selected.');
end

ncFullPath = fullfile(ncPath, ncFile);

%% ==========================================================
% UNPACK FILES
%% ==========================================================

Log_Matrix = Log_File_Unpacker(logFullPath);

NC_Matrix = NC_File_Unpacker(ncFullPath); 

%% ==========================================================
% Mission Data Matrix
%% ==========================================================

Mission_Data_Matrix = Create_Mission_Data_Matrix(Log_Matrix, NC_Matrix);

%% ==========================================================
%% Digital Twin
%% ==========================================================

Nominal_Sim_Matrix = Digital_Twin(Mission_Data_Matrix, coefficientsV3, parametersV3);

%% ==========================================================
%% Diagnoser
%% ==========================================================

%% ==========================================================
%  Mission-Nominal comparator
%% ==========================================================
% % Compare simulated nominal mission to actual ENG mission
% Diagnose = missioncompare(Nom_Sim_Matrix, Eng_Matrix);
% 
% % need mission comparator to output totatl error percentange for next stage
% 
% %% Display Diagnose Results
% disp(Diagnose);
% 
% %% If/else statement to determine if the mis-fault comparator will activate
% 
% if total_error >= 40
%     % continue to next iteration of loop, if error bound is => 40%
%     return
% else
%     % stop the loop / exit function, if error bound is < 40%
% end 


%% ==========================================================
%  Mission-Fualt comparator
%% ==========================================================
%% Simulate fault cases
% Wing_75_Sim_Matrix = Create_Dynamics_Matrix(Log_Matrix, NC_Matrix, coefficients_75, parameters_75);
% 
% Wing_50_Sim_Matrix = Create_Dynamics_Matrix(Log_Matrix, NC_Matrix, coefficients_50, parameters_50);
% 
% Wing_25_Sim_Matrix = Create_Dynamics_Matrix(Log_Matrix, NC_Matrix, coefficients_50, parameters_50);
% 
% Rudder_75_Sim_Matrix = Create_Dynamics_Matrix(Log_Matrix, NC_Matrix, coefficients_75, parameters_75);
% 
% Rudder_50_Sim_Matrix = Create_Dynamics_Matrix(Log_Matrix, NC_Matrix, coefficients_50, parameters_50);
% 
% Rudder_25_Sim_Matrix = Create_Dynamics_Matrix(Log_Matrix, NC_Matrix, coefficients_50, parameters_50);
% 
% %% Compare fualt case matricies to mission data
% 
% Isolate_Wing_75 = missioncompare(75_Sim_Matrix, Eng_Matrix);
% 
% Isolate_Wing_50 = missioncompare(50_Sim_Matrix, Eng_Matrix);
% 
% Isolate_Wing_25 = missioncompare(50_Sim_Matrix, Eng_Matrix);
% 
% Isolate_Rudder_75 = missioncompare(75_Sim_Matrix, Eng_Matrix);
% 
% Isolate_Rudder_50 = missioncompare(50_Sim_Matrix, Eng_Matrix);
% 
% Isolate_Rudder_25 = missioncompare(50_Sim_Matrix, Eng_Matrix);
% 
% %% graph and display results
% 
% % graph each error % from simulatated case
% % display lowest total error
% % say 'The most likely fault is xx% wing/rudder brakage based on data'
% 
% 
% 
% 




















