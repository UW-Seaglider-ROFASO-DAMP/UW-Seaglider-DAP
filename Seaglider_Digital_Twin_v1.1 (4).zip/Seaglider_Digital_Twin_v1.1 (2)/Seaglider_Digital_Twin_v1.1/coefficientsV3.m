function coefs = coefficientsV3()
% COEFFICIENTSV3 Creates coefficient lookup tables for dynamicsV3.m
%
% Usage:
%   coefs = coefficientsV3();
%
% dynamicsV3 expects coefficient tables where rows correspond to alphas
% and columns correspond to betas. Replace these placeholder values with
% wind tunnel / CFD / experimental coefficient tables when available.

%% Lookup grid
coefs.alphas = -20:5:20;         % deg, angle of attack grid, 1 x M
coefs.betas  = -20:5:20;         % deg, sideslip angle grid, 1 x N

[Beta, Alpha] = meshgrid(coefs.betas, coefs.alphas);

%% Placeholder coefficient models
% Lift coefficient: mostly depends on alpha
coefs.CLs = 0.08 .* Alpha;

% Drag coefficient: base drag + quadratic alpha/beta drag
coefs.CDs = 0.05 + 0.002 .* Alpha.^2 + 0.001 .* Beta.^2;

% Side-force coefficient: mostly depends on beta
coefs.CYs = 0.02 .* Beta;

% Roll moment coefficient: mostly driven by beta/roll coupling
coefs.Croll = -0.005 .* Beta;

% Pitch moment coefficient: restoring pitch tendency
coefs.Cpitch = -0.01 .* Alpha;

% Yaw moment coefficient: restoring yaw/sideslip tendency
coefs.Cyaw = -0.005 .* Beta;

end
