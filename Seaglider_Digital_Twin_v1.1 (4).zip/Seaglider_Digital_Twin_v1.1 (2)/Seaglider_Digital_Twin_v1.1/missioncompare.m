function Diagnose = missioncompare(DT_Output, MI_Output)
% missioncompare
% Seaglider Mission-Sim Comparator for Diagnoser
% Author: Dante Weerasooriya
% Date: April 2026

%% Extract variable names
varNames_DT_raw = strtrim(string(DT_Output(1, :)));
varNames_MI_raw = strtrim(string(MI_Output(1, :)));

% Make MATLAB-safe variable names for structs
varNames_DT = matlab.lang.makeValidName(varNames_DT_raw);
varNames_MI = matlab.lang.makeValidName(varNames_MI_raw);

%% Check variable count
if size(DT_Output, 2) ~= size(MI_Output, 2)
    error('MissionCompare:VariableCountMismatch', ...
          'Digital Twin and Mission data have different numbers of variables.');
end

%% Check variable names match
if ~isequal(varNames_DT_raw, varNames_MI_raw)
    disp("DT variable names:");
    disp(varNames_DT_raw');

    disp("MI variable names:");
    disp(varNames_MI_raw');

    error('MissionCompare:VariableNameMismatch', ...
          'Variable names do not match between DT and MI data.');
end

%% Convert data sections to numeric
DT_data = cell2mat(DT_Output(2:end, :));
MI_data = cell2mat(MI_Output(2:end, :));

%% Find time column
timeIdx = findColumn(varNames_DT_raw, ["elaps_t", "time", "secs", "st_secs"]);

if isempty(timeIdx)
    error("Could not find time column.");
end

time_DT = DT_data(:, timeIdx);
time_MI = MI_data(:, timeIdx);

%% Check time length
if length(time_DT) ~= length(time_MI)
    error('MissionCompare:TimeMismatch', ...
          'Digital Twin and Mission data have different numbers of time samples.');
end

%% Build DT and MI structs
DT = struct();
MI = struct();

for i = 1:length(varNames_DT)
    safeName = char(varNames_DT(i));

    DT.(safeName) = DT_data(:, i);
    MI.(safeName) = MI_data(:, i);
end

%% Trimming logic
time = time_DT;
T = time(end) - time(1);
t0 = time(1);

trimMask = (time > t0 + 0.2*T) & (time < t0 + 0.8*T);

%% Initialize Diagnose struct
Diagnose = struct();
Diagnose.VariableNamesOriginal = varNames_DT_raw;
Diagnose.VariableNamesSafe = varNames_DT;
Diagnose.Diff = struct();
Diagnose.Failures = struct();
Diagnose.Plots = struct();
Diagnose.Excursions = struct();

%% Create folder for plots
saveFolder = fullfile(pwd, 'MS_Comparator_Plots');

if ~exist(saveFolder, 'dir')
    mkdir(saveFolder);
end

%% Loop through variables
for i = 1:length(varNames_DT)

    % Skip time column
    if i == timeIdx
        continue;
    end

    rawName = varNames_DT_raw(i);
    safeName = char(varNames_DT(i));

    DT_trim = DT.(safeName)(trimMask);
    MI_trim = MI.(safeName)(trimMask);
    t_trim = time(trimMask);

    %% Avoid divide-by-zero percent error issue
    denom = abs(DT_trim);
    denom(denom < 1e-6) = 1e-6;

    %% Percent error
    E = abs((MI_trim - DT_trim) ./ denom) * 100;

    %% Excursion mask
    excursionMask = E > 2;

    %% Final Diff metric
    Diff = sum(E(excursionMask));
    Diagnose.Diff.(safeName) = Diff;

    %% Threshold logic
    if Diff > 40
        Diagnose.Failures.(safeName) = Diff;
    end

    %% Record excursion time intervals
    idx = find(excursionMask);
    intervals = [];

    if ~isempty(idx)
        d = diff(idx);
        breaks = [0; find(d > 1); length(idx)];

        for b = 1:length(breaks)-1
            seg = idx(breaks(b)+1 : breaks(b+1));
            intervals = [intervals; t_trim(seg(1)) t_trim(seg(end))]; %#ok<AGROW>
        end
    end

    Diagnose.Excursions.(safeName) = intervals;

    %% Plot hidden
    fig = figure('Visible','off');

    plot(t_trim, DT_trim, 'b', 'LineWidth', 1.5);
    hold on;
    plot(t_trim, MI_trim, 'r', 'LineWidth', 1.5);

    lower = DT_trim * 0.98;
    upper = DT_trim * 1.02;

    plot(t_trim, lower, 'k--', 'LineWidth', 1);
    plot(t_trim, upper, 'k--', 'LineWidth', 1);

    xlabel('Time');
    ylabel(rawName);
    legend('DT','MI','-2%','+2%');
    title("DT vs MI: " + rawName);
    grid on;

    filePath = fullfile(saveFolder, safeName + ".png");

    saveas(fig, filePath);
    close(fig);

    Diagnose.Plots.(safeName) = filePath;

end

%% Summary output
if isempty(fieldnames(Diagnose.Failures))
    fprintf('\n✓ All variables within acceptable limits.\n\n');
else
    fprintf('\n⚠ FAILURES DETECTED:\n');

    failVars = fieldnames(Diagnose.Failures);

    for k = 1:length(failVars)
        name = failVars{k};
        value = Diagnose.Failures.(name);

        fprintf('   %s exceeded threshold with Diff = %.2f%%\n', name, value);
    end

    fprintf('\n');
end

end


function idx = findColumn(headers, possibleNames)

    idx = [];

    for i = 1:length(possibleNames)
        idx = find(strcmpi(headers, possibleNames(i)), 1);

        if ~isempty(idx)
            return;
        end
    end

end









