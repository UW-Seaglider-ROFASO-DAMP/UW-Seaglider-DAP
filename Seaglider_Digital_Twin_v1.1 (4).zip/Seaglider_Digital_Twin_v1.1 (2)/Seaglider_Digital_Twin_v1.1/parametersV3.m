function params = parametersV3()
% PARAMETERSV3 Creates parameter structure for dynamicsV3.m
%
% Usage:
%   params = parametersV3();
%
% These values are starter/default values. Replace TBD values with measured
% seaglider values when available.

%% Target / mission parameters
params.heading_desired = 0;      % deg, desired heading for dive

%% Aerodynamic / hydrodynamic geometry
params.S    = 0.10;              % m^2, wing/reference surface area [TBD]
params.cbar = 0.10;              % m, mean aerodynamic chord [TBD]
params.b    = 1.00;              % m, wing span [TBD]

%% Battery properties
params.rpbat = 0.025;            % m, radius from x-axis to battery CG [TBD]
params.mbat  = 4.00;             % kg, battery pack mass [TBD]

%% Whole glider properties
params.Vstatic = 5.20e-2;        % m^3, displaced volume without VBD [TBD]
params.Ms      = 52.0;           % kg, stationary mass [TBD]

% Added mass matrix, kg
params.Mf = zeros(3,3);          % replace with measured/estimated added mass

% Added mass inertia matrix, kg*m^2
params.Jf = zeros(3,3);          % replace with measured/estimated added inertia

% Stationary mass inertia matrix, kg*m^2
params.Js = diag([1.0, 8.0, 8.0]); % [Ixx Iyy Izz], replace with CAD values

%% Ocean / environmental properties
params.ambtemp  = 10;            % deg C, ambient surface temperature [TBD]
params.temp     = 10;            % deg C, local water temperature [TBD]
params.pressure = 0;             % pressure/depth input used in dynamicsV3 [TBD]
params.rho      = 1028.1;        % kg/m^3, seawater density [currently not used directly]
params.salt     = 35;            % PSU, salinity [currently not used directly]

%% Optional current model placeholders
params.water_v       = 0;        % m/s, water current velocity [optional]
params.water_heading = 0;        % deg, water current heading [optional]

end
