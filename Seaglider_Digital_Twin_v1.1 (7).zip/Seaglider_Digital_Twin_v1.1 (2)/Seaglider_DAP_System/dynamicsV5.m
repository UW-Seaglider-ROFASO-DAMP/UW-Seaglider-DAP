function X_dyn = dynamicsV5(X,U,coefs,params)
% dynamicsV5
%
% Seaglider dynamics function for Digital Twin via momentum.
%
% State vector:
%   X = [phidot; thetadot; headingdot; phi; theta; heading; u; v; w; x; y; z]
%
% Units:
%   phidot, thetadot, headingdot = deg/s
%   phi, theta, heading           = deg
%   u, v, w                       = m/s
%   x, y, z                       = m
%
% Control vector:
%   U = [pitch_ctl; phi_bat; VBD_cc]
%
% Important updates:
%   - Adds angular damping
%   - Adds translational damping
%   - Reduces hydrodynamic moment authority
%   - Protects Euler kinematics near +/- 90 deg pitch
%   - Limits extreme derivatives to prevent ode45 blow-up

%% -----------------------------
% Unpack state vector
%% -----------------------------

phidot_deg     = X(1);
thetadot_deg   = X(2);
headingdot_deg = X(3);

phi_deg     = X(4);
theta_deg   = X(5);
heading_deg = X(6);

u = X(7);
v = X(8);
w = X(9);

x = X(10); %#ok<NASGU>
y = X(11); %#ok<NASGU>
z = X(12); %#ok<NASGU>

%% -----------------------------
% Safety limits before dynamics
%% -----------------------------

% Prevent Euler singularity near theta = +/- 90 deg
theta_deg = max(min(theta_deg, 70), -70);

% Prevent insane velocities from making q explode
u = max(min(u, 1.5), -1.5);
v = max(min(v, 1.5), -1.5);
w = max(min(w, 1.5), -1.5);

% Convert rates and angles to radians
phidot     = deg2rad(phidot_deg);
thetadot   = deg2rad(thetadot_deg);
headingdot = deg2rad(headingdot_deg);

phi     = deg2rad(phi_deg);
theta   = deg2rad(theta_deg);
heading = deg2rad(heading_deg);

%% -----------------------------
% Unpack control input
%% -----------------------------

pitch_ctl = U(1);   % battery position, m
phi_bat   = U(2);   % battery roll angle, deg
VBD_cc    = U(3);   % VBD volume/count in cc

% Sign convention from original dynamics
x_bat = -pitch_ctl;

%% -----------------------------
% Unpack parameters
%% -----------------------------

heading_desired = deg2rad(params.heading_desired);

S    = params.S;
cbar = params.cbar;
b    = params.b;

Vol_static = params.Vstatic;

Mf = params.Mf;
Jf = params.Jf;

ms = params.Ms;
Js = params.Js;

mbat = params.mbat;

rho = params.rho;
T0  = params.ambtemp;
T   = params.temp;      %#ok<NASGU>
P   = params.pressure;  %#ok<NASGU>

%% -----------------------------
% Battery / CG geometry
%% -----------------------------

VCB = -0.00362;
VCG_bat = -0.01082;

rpbat = sqrt(VCB^2 + VCG_bat^2 - 2 * VCB * VCG_bat * cosd(phi_bat));

rp = [ ...
    x_bat;
    rpbat * sind(phi_bat);
    rpbat * cosd(phi_bat)];

skew = @(vec) [ ...
     0       -vec(3)   vec(2);
     vec(3)   0       -vec(1);
    -vec(2)   vec(1)   0];

rpx = skew(rp);

%% -----------------------------
% Rotation / DCM
%% -----------------------------

psi = heading - heading_desired;

% Requires Aerospace Toolbox.
% DCM_gb maps glide path frame to body frame.
DCM_gb = angle2dcm(psi, theta, phi);
DCM_bg = DCM_gb.';

%% -----------------------------
% Velocity and flow angles
%% -----------------------------

V_g = [u; v; w];
V_b = DCM_gb * V_g;

ub = V_b(1);
vb = V_b(2);
wb = V_b(3);

V = sqrt(u^2 + v^2 + w^2);

if V > 1e-6
    alpha = atan2(wb, ub) * 180/pi;
    beta  = asin(max(min(vb / V, 1), -1)) * 180/pi;
else
    alpha = 0;
    beta  = 0;
end

%% -----------------------------
% Mass and inertia
%% -----------------------------

M = ms * eye(3) + Mf;
J = Js * ms + Jf;

%% -----------------------------
% Coefficient lookup
%% -----------------------------

alpha_clamp = max(min(alpha, max(coefs.alphas)), min(coefs.alphas));
beta_clamp  = max(min(abs(beta), max(coefs.betas)), min(coefs.betas));

if isfield(coefs,'F_CL')
    CL     = coefs.F_CL(alpha_clamp, beta_clamp);
    CD     = coefs.F_CD(alpha_clamp, beta_clamp);
    CY     = coefs.F_CY(alpha_clamp, beta_clamp);
    Croll  = coefs.F_Croll(alpha_clamp, beta_clamp);
    Cpitch = coefs.F_Cpitch(alpha_clamp, beta_clamp);
    Cyaw   = coefs.F_Cyaw(alpha_clamp, beta_clamp);
else
    CL     = interp2(coefs.betas, coefs.alphas, coefs.CLs,     beta_clamp, alpha_clamp, 'linear');
    CD     = interp2(coefs.betas, coefs.alphas, coefs.CDs,     beta_clamp, alpha_clamp, 'linear');
    CY     = interp2(coefs.betas, coefs.alphas, coefs.CYs,     beta_clamp, alpha_clamp, 'linear');
    Croll  = interp2(coefs.betas, coefs.alphas, coefs.Croll,   beta_clamp, alpha_clamp, 'linear');
    Cpitch = interp2(coefs.betas, coefs.alphas, coefs.Cpitch,  beta_clamp, alpha_clamp, 'linear');
    Cyaw   = interp2(coefs.betas, coefs.alphas, coefs.Cyaw,    beta_clamp, alpha_clamp, 'linear');
end

%% -----------------------------
% Hydrodynamic forces
%% -----------------------------

q_dyn = 0.5 * rho * V^2;

L = q_dyn * CL * S;
D = q_dyn * CD * S;
Y = q_dyn * CY * S;

F_hydro = [-D; Y; -L];

%% -----------------------------
% Translational damping
%% -----------------------------

Ku = 25;
Kv = 40;
Kw = 40;

F_damp = [ ...
    -Ku * ub;
    -Kv * vb;
    -Kw * wb];

F_hydro = F_hydro + F_damp;

%% -----------------------------
% Buoyancy / gravity
%% -----------------------------

g = 9.81;

Vol_blad = (VBD_cc + 1426.7) * 1e-6;
Vol_disp = Vol_static + Vol_blad;

m_total = ms + mbat;

g_b = DCM_gb * [0; 0; g];

% Positive value means vehicle is heavier than displaced water.
B = g_b * (m_total - rho * Vol_disp);

%% -----------------------------
% Hydrodynamic moments
%% -----------------------------

momentScale = 0.25;

Mp = momentScale * q_dyn * Croll  * b    * S;
Mq = momentScale * q_dyn * Cpitch * cbar * S;
Mr = momentScale * q_dyn * Cyaw   * b    * S;

Torques = [Mp; Mq; Mr];

%% -----------------------------
% Euler rate kinematics
%% -----------------------------

eta_dot = [phidot; thetadot; headingdot];

H = [ ...
    1,  sin(phi)*tan(theta),   cos(phi)*tan(theta);
    0,  cos(phi),             -sin(phi);
    0,  sin(phi)/cos(theta),   cos(phi)/cos(theta)];

Hdot = [ ...
    0,  cos(phi)*phidot*tan(theta) + sin(phi)*sec(theta)^2*thetadot, ...
       -sin(phi)*phidot*tan(theta) + cos(phi)*sec(theta)^2*thetadot;
    0, -sin(phi)*phidot, ...
       -cos(phi)*phidot;
    0,  cos(phi)*phidot*sec(theta) + sin(phi)*sec(theta)*tan(theta)*thetadot, ...
       -sin(phi)*phidot*sec(theta) + cos(phi)*sec(theta)*tan(theta)*thetadot];

Omega = H \ eta_dot;

%% -----------------------------
% Angular damping
%% -----------------------------

p = Omega(1);
q_rate = Omega(2);
r = Omega(3);

Kp_damp = 8;
Kq_damp = 12;
Kr_damp = 8;

DampingTorque = [ ...
    -Kp_damp * p;
    -Kq_damp * q_rate;
    -Kr_damp * r];

Torques = Torques + DampingTorque;

%% -----------------------------
% Momentum dynamics
%% -----------------------------

Pp = mbat * (V_b + cross(Omega, rp));

Feq = cross(M * V_b + Pp, Omega) + B + F_hydro;

veq = [ ...
    M + mbat * eye(3), ...
   -mbat * rpx];

Teq = cross(J * Omega + cross(rp, Pp), Omega) ...
    + cross(M * V_b, V_b) ...
    + mbat * cross(rp, g_b) ...
    + Torques;

Omegaeq = [ ...
    mbat * rpx, ...
    J - mbat * rpx * rpx];

accels = [veq; Omegaeq] \ [Feq; Teq];

Vdot_b   = accels(1:3);
Omegadot = accels(4:6);

%% -----------------------------
% Convert accelerations back to output frame
%% -----------------------------

eta_Ddot = Hdot * Omega + H * Omegadot;

Vdot_g = DCM_bg * (Vdot_b + cross(Omega, V_b));

udot = Vdot_g(1);
vdot = Vdot_g(2);
wdot = Vdot_g(3);

phiDdot     = rad2deg(eta_Ddot(1));
thetaDdot   = rad2deg(eta_Ddot(2));
headingDdot = rad2deg(eta_Ddot(3));

phidot_out     = rad2deg(phidot);
thetadot_out   = rad2deg(thetadot);
headingdot_out = rad2deg(headingdot);

%% -----------------------------
% Derivative safety limits
%% -----------------------------

phiDdot     = max(min(phiDdot,     20), -20);
thetaDdot   = max(min(thetaDdot,   20), -20);
headingDdot = max(min(headingDdot, 20), -20);

udot = max(min(udot, 0.5), -0.5);
vdot = max(min(vdot, 0.5), -0.5);
wdot = max(min(wdot, 0.5), -0.5);

phidot_out     = max(min(phidot_out,     20), -20);
thetadot_out   = max(min(thetadot_out,   20), -20);
headingdot_out = max(min(headingdot_out, 20), -20);

u = max(min(u, 1.5), -1.5);
v = max(min(v, 1.5), -1.5);
w = max(min(w, 1.5), -1.5);

%% -----------------------------
% Output state derivative
%% -----------------------------

X_dyn = [ ...
    phiDdot;
    thetaDdot;
    headingDdot;
    phidot_out;
    thetadot_out;
    headingdot_out;
    udot;
    vdot;
    wdot;
    u;
    v;
    w];

end